"""Course au trait - TP CPGE : mes_fonctions.py, programme complet
du tronc commun (TP 1 à 8 et 11) et de l'option SI (SI-1 à SI-6).

Toutes les fonctions sont écrites (celles des corrigés des fiches).
Un état est un quadruplet (x, y, vx, vy).
"""
import heapq
import random
from collections import deque
from squelette import ACC, segment_libre, touche, dans, choisir, lire, cap_depart


# ---- TP 1 : les coups permis et le glouton ----
def ecart(a, lo, hi):
    """L'écart entre a et l'intervalle [lo, hi] (0 si a est dedans)."""
    if a < lo:
        return lo - a
    if a > hi:
        return a - hi
    return 0


def distance(p, arrivee):
    meilleure = -1
    for r in arrivee:
        dx = ecart(p[0], r[0], r[2])
        dy = ecart(p[1], r[1], r[3])
        d = (dx ** 2 + dy ** 2) ** 0.5
        if meilleure == -1 or d < meilleure:
            meilleure = d
    return meilleure


def coups_possibles(grille, cap, etat):
    x, y, vx, vy = etat
    res = []
    for ax, ay in ACC:
        nvx, nvy = vx + ax, vy + ay
        if (nvx, nvy) == (0, 0):
            permis = False                    # interdit de s'arrêter
        elif (vx, vy) == (0, 0):              # au départ : bon cap
            permis = cap is None or nvx * cap[0] + nvy * cap[1] > 0
        else:
            permis = nvx * vx + nvy * vy >= 0     # pas de demi-tour
        if permis and segment_libre(grille, (x, y), (x + nvx, y + nvy)):
            res.append((x + nvx, y + nvy, nvx, nvy))
    return res


def glouton(grille, depart, arrivee, cap):
    etat = (depart[0], depart[1], 0, 0)
    chemin = [etat]
    for i in range(100):
        suivants = coups_possibles(grille, cap, etat)
        if len(suivants) == 0:
            return "bloque", chemin
        etat = suivants[0]
        for e in suivants:        # < strict : à égalité, le premier de ACC
            if distance((e[0], e[1]), arrivee) < distance((etat[0], etat[1]), arrivee):
                etat = e
        chemin.append(etat)
        if dans(arrivee, (etat[0], etat[1])):
            return "arrive", chemin
    return "boucle", chemin


# ---- TP 2 : le graphe des états et le parcours en largeur ----
def construire(grille, depart, arrivee, cap):
    s0 = (depart[0], depart[1], 0, 0)
    adj = {s0: None}
    a_traiter = deque([s0])
    while len(a_traiter) > 0:
        s = a_traiter.popleft()
        if dans(arrivee, (s[0], s[1])):
            adj[s] = []                   # arrivée : la course est finie
        else:
            adj[s] = coups_possibles(grille, cap, s)
            for t in adj[s]:
                if t not in adj:
                    adj[t] = None
                    a_traiter.append(t)
    return adj


def remonter(pere, s):
    chemin = []
    while s is not None:
        chemin = [s] + chemin
        s = pere[s]
    return chemin


def largeur(adj, s0, arrivee):
    """Le Stratège : parcours en largeur du graphe adj depuis s0.
    Précondition : adj contient s0 et tous les états qu'on atteint depuis s0 ;
    arrivee est une liste de rectangles (x0, y0, x1, y1).
    Postcondition : renvoie (n, chemin, découverts) ; chemin va de s0 à un état
    d'arrivée en n coups, le plus petit nombre possible ; (None, [], découverts)
    si l'arrivée est inaccessible ; découverts compte les états vus."""
    pere = {s0: None}
    file = deque([s0])
    while len(file) > 0:
        s = file.popleft()
        for t in adj[s]:
            if t not in pere:
                pere[t] = s
                if dans(arrivee, (t[0], t[1])):
                    chemin = remonter(pere, t)
                    return len(chemin) - 1, chemin, len(pere)
                file.append(t)
    return None, [], len(pere)


def profondeur(adj, s0, arrivee):
    """Comme largeur, avec une pile."""
    pere = {s0: None}
    pile = [s0]
    while len(pile) > 0:
        s = pile.pop()
        for t in adj[s]:
            if t not in pere:
                pere[t] = s
                if dans(arrivee, (t[0], t[1])):
                    chemin = remonter(pere, t)
                    return len(chemin) - 1, chemin, len(pere)
                pile.append(t)
    return None, [], len(pere)


# ---- TP 3 : les coûts et Dijkstra ----
def cases_sable(grille):
    sable = []
    for y in range(len(grille)):
        for x in range(len(grille[y])):
            if grille[y][x] == "s":
                sable.append((x, y, x + 1, y + 1))
    return sable


def cout(sable, s, t, c):
    for r in sable:
        if touche((s[0], s[1]), (t[0], t[1]), r):
            return c
    return 1


def cout_chemin(sable, chemin, c):
    total = 0
    for i in range(len(chemin) - 1):
        total = total + cout(sable, chemin[i], chemin[i + 1], c)
    return total


def dijkstra(sable, adj, s0, arrivee, c):
    """Le Stratège pondéré : Dijkstra, avec un tas.
    Précondition : comme largeur ; sable est la liste des cases de sable ;
    c >= 1 est le coût d'un coup qui touche du sable.
    Postcondition : renvoie (coût, chemin, fixés, découverts) ; chemin va de s0
    à un état d'arrivée et son coût, le plus petit possible, vaut coût ;
    (None, [], fixés, découverts) si l'arrivée est inaccessible."""
    dist = {s0: 0}
    pere = {s0: None}
    tas = [(0, s0)]
    fixes = {}
    while len(tas) > 0:
        d, s = heapq.heappop(tas)
        if s not in fixes:
            fixes[s] = True
            if dans(arrivee, (s[0], s[1])):
                return d, remonter(pere, s), len(fixes), len(dist)
            for t in adj[s]:
                nd = d + cout(sable, s, t, c)
                if t not in dist or nd < dist[t]:
                    dist[t] = nd
                    pere[t] = s
                    heapq.heappush(tas, (nd, t))
    return None, [], len(fixes), len(dist)


# ---- TP 4 : l'heuristique cinématique et A* ----
def coups_min_1d(lo, hi, v):
    n = 0
    while not (n * v - n * (n + 1) // 2 <= hi
               and n * v + n * (n + 1) // 2 >= lo):
        n = n + 1
    return n


def h(etat, arrivee):
    x, y, vx, vy = etat
    meilleur = -1
    for r in arrivee:
        nx = coups_min_1d(r[0] - x, r[2] - x, vx)
        ny = coups_min_1d(r[1] - y, r[3] - y, vy)
        if nx > ny:
            n = nx
        else:
            n = ny
        if meilleur == -1 or n < meilleur:
            meilleur = n
    return meilleur


def vol(etat, arrivee):
    """La distance à vol d'oiseau (l'heuristique du Fonceur)."""
    return distance((etat[0], etat[1]), arrivee)


def astar(sable, adj, s0, arrivee, c, hf):
    """Renvoie (coût, chemin, états fixés, états découverts)."""
    g = {s0: 0}
    pere = {s0: None}
    tas = [(hf(s0, arrivee), 0, s0)]
    fixes = {}
    while len(tas) > 0:
        f, d, s = heapq.heappop(tas)
        if s not in fixes:
            fixes[s] = True
            if dans(arrivee, (s[0], s[1])):
                return d, remonter(pere, s), len(fixes), len(g)
            for t in adj[s]:
                nd = d + cout(sable, s, t, c)
                if t not in g or nd < g[t]:
                    g[t] = nd
                    pere[t] = s
                    heapq.heappush(tas, (nd + hf(t, arrivee), nd, t))
    return None, [], len(fixes), len(g)


def admissible(sable, adj, arrivee, c, hf):
    """Compte les états où l'estimation hf dépasse le coût réel (TP 4).
    Renvoie (états testés, erreurs) ; un état d'où l'arrivée est
    inaccessible n'est pas testé."""
    testes, erreurs = 0, 0
    for s in adj:
        reel = dijkstra(sable, adj, s, arrivee, c)[0]
        if reel is not None:         # sinon, l'arrivée est inaccessible depuis s
            testes = testes + 1
            if hf(s, arrivee) > reel:
                erreurs = erreurs + 1
    return testes, erreurs


# ---- TP 5 : spécifier, tester, comparer à un oracle ----
def mes_tests(dijkstra):
    """Mes tests de dijkstra (activité 2). Le labo appelle mes_tests avec la
    vraie dijkstra, puis avec six versions fausses : chaque version fausse doit
    faire échouer au moins un assert, la vraie aucun."""
    circuits = {}
    for nom in ["DA", "N", "S"]:
        grille, depart, arrivee = lire(open("circuit_" + nom + ".txt").read())
        adj = construire(grille, depart, arrivee, cap_depart(grille, depart, arrivee))
        circuits[nom] = (cases_sable(grille), adj, (depart[0], depart[1], 0, 0), arrivee)
    sable, adj, s0, arrivee = circuits["DA"]
    cout_da, chemin, fixes, vus = dijkstra(sable, adj, s0, arrivee, 3)
    assert cout_da == 1                          # le plus petit circuit : un coup
    assert chemin[0] == s0                       # le chemin part du départ
    assert dans(arrivee, chemin[-1][:2])         # et finit sur l'arrivée
    sable, adj, s0, arrivee = circuits["N"]
    assert dijkstra(sable, adj, s0, arrivee, 3)[0] is None   # aucune solution
    sable, adj, s0, arrivee = circuits["S"]
    cout_s, chemin, fixes, vus = dijkstra(sable, adj, s0, arrivee, 3)
    assert cout_s == 5                           # le sable compte (coût 3)
    assert cout_chemin(sable, chemin, 3) == cout_s     # le coût annoncé est celui du chemin
    attendus = [4, 5, 5, 5, 5, 5, 5]             # le jeu, sable 1 à 7 (TP 3)
    for c in range(1, 8):
        assert dijkstra(sable, adj, s0, arrivee, c)[0] == attendus[c - 1]


def alea(graine, L=12, H=7, p_mur=0.08, p_sable=0.15):
    """Un circuit aléatoire, en grille texte lisible par lire.
    Précondition : graine entier ; L >= 4 et H >= 1 ; p_mur et p_sable
    positives, de somme au plus 1.
    Postcondition : une chaîne de H lignes de L caractères, chacune terminée
    par "\\n" ; chaque case vaut "#", "s" ou ".", sauf D en (1, H // 2) et A en
    (L - 2, H // 2) ; deux appels avec la même graine renvoient le même circuit.
    Le circuit peut n'avoir aucune solution."""
    r = random.Random(graine)
    lignes = []
    for y in range(H):
        ligne = []
        for x in range(L):
            u = r.random()
            if u < p_mur:
                ligne.append("#")
            elif u < p_mur + p_sable:
                ligne.append("s")
            else:
                ligne.append(".")
        lignes.append(ligne)
    lignes[H // 2][1] = "D"
    lignes[H // 2][L - 2] = "A"
    texte = ""
    for ligne in lignes:
        for car in ligne:
            texte = texte + car
        texte = texte + "\n"
    return texte


def oracle(sable, adj, s0, arrivee, c):
    """Le programme de référence : le plus petit coût pour atteindre l'arrivée
    (None si elle est inaccessible), par une file et des distances corrigées
    tant qu'elles baissent. Écrit autrement que dijkstra, pour la contrôler."""
    dist = {s0: 0}
    file = deque([s0])
    while len(file) > 0:
        s = file.popleft()
        for t in adj[s]:
            nd = dist[s] + cout(sable, s, t, c)
            if t not in dist or nd < dist[t]:
                dist[t] = nd
                file.append(t)          # t devra propager sa nouvelle valeur
    meilleur = None
    for s, d in dist.items():
        if dans(arrivee, (s[0], s[1])) and (meilleur is None or d < meilleur):
            meilleur = d
    return meilleur


def chemin_valide(sable, adj, s0, arrivee, c, chemin, cout_annonce):
    """Vrai si chemin part de s0, finit à l'arrivée, ne joue que des coups
    permis et coûte cout_annonce (TP 5)."""
    if len(chemin) == 0 or chemin[0] != s0:
        return False
    fin = chemin[len(chemin) - 1]
    if not dans(arrivee, (fin[0], fin[1])):
        return False
    for i in range(len(chemin) - 1):
        permis = False               # chemin[i + 1] est-il un successeur de chemin[i] ?
        for t in adj[chemin[i]]:
            if t == chemin[i + 1]:
                permis = True
        if not permis:
            return False
    return cout_chemin(sable, chemin, c) == cout_annonce


# ---- TP 6 : la programmation dynamique ----
INF = float("inf")


def reste_naif(sable, adj, s, k, arrivee, c, cpt):
    cpt[0] = cpt[0] + 1
    if dans(arrivee, (s[0], s[1])):
        return 0
    if k == 0:
        return INF
    meilleur = INF                         # un cul-de-sac vaut l'infini
    for t in adj[s]:
        v = cout(sable, s, t, c) + reste_naif(sable, adj, t, k - 1, arrivee, c, cpt)
        if v < meilleur:
            meilleur = v
    return meilleur


def reste(sable, adj, s, k, arrivee, c, memo, cpt):
    cpt[0] = cpt[0] + 1
    if dans(arrivee, (s[0], s[1])):
        return 0
    if k == 0:
        return INF
    if (s, k) in memo:
        return memo[(s, k)]
    meilleur = INF
    for t in adj[s]:
        v = cout(sable, s, t, c) + reste(sable, adj, t, k - 1, arrivee, c, memo, cpt)
        if v < meilleur:
            meilleur = v
    memo[(s, k)] = meilleur
    return meilleur


def reconstruire(sable, adj, s, k, arrivee, c, memo):
    chemin = [s]
    while not dans(arrivee, (s[0], s[1])):
        v = reste(sable, adj, s, k, arrivee, c, memo, [0])
        i = 0                              # le premier successeur qui réalise v
        while cout(sable, s, adj[s][i], c) + reste(sable, adj, adj[s][i], k - 1,
                                                   arrivee, c, memo, [0]) != v:
            i = i + 1
        s = adj[s][i]
        k = k - 1
        chemin.append(s)
    return chemin


def reste_bas(sable, adj, s0, K, arrivee, c):
    """Programmation dynamique de bas en haut (TP 6) : remplit R[k][s]
    pour k de 0 à K. Renvoie (R(s0, K), nombre de valeurs calculées)."""
    R = [{}]
    for s in adj:                          # k = 0
        if dans(arrivee, (s[0], s[1])):
            R[0][s] = 0
        else:
            R[0][s] = INF
    for k in range(1, K + 1):
        R.append({})
        for s in adj:
            if dans(arrivee, (s[0], s[1])):
                R[k][s] = 0
            else:
                meilleur = INF
                for t in adj[s]:
                    v = cout(sable, s, t, c) + R[k - 1][t]
                    if v < meilleur:
                        meilleur = v
                R[k][s] = meilleur
    return R[K][s0], len(adj) * (K + 1)


# ---- TP 7 : les k plus proches voisins ----
def lire_exemples(texte, circuits=None):
    """Lit un jeu d'exemples exporté par le labo (fichier CSV) : (Xa, Ya).
    circuits : les lettres des circuits à garder ("ABC"), tous si None."""
    Xa, Ya = [], []
    lignes = texte.split("\n")
    for ligne in lignes[1:]:                   # la ligne 0 est l'en-tête
        champs = ligne.split(";")
        garder = len(champs) >= 6
        if garder and circuits is not None and len(champs) > 6:
            garder = champs[6].split()[1] in circuits    # « Circuit A » -> A
        if garder:
            Xa.append((int(champs[0]), int(champs[1]), int(champs[2]), int(champs[3])))
            Ya.append((int(champs[4]), int(champs[5])))
    return Xa, Ya


def dist2(p, q):
    total = 0
    for i in range(len(p)):
        total = total + (p[i] - q[i]) ** 2
    return total


def knn(Xa, Ya, x, k):
    if k > len(Xa):
        k = len(Xa)
    d = [dist2(Xa[i], x) for i in range(len(Xa))]
    pris = [False] * len(Xa)
    voisins = []                       # du plus proche au plus lointain
    for j in range(k):
        m = -1
        for i in range(len(Xa)):       # < strict : à égalité, le plus petit indice
            if not pris[i] and (m == -1 or d[i] < d[m]):
                m = i
        pris[m] = True
        voisins.append(m)
    votes = {}
    for i in voisins:
        if Ya[i] in votes:
            votes[Ya[i]] = votes[Ya[i]] + 1
        else:
            votes[Ya[i]] = 1
    m = 0
    for e in votes:
        if votes[e] > m:
            m = votes[e]
    j = 0                              # égalité de votes : le voisin le plus proche
    while votes[Ya[voisins[j]]] != m:
        j = j + 1
    return Ya[voisins[j]]


def voisins_tri(Xa, x, k):
    """Les indices des k plus proches voisins de x, par un tri (TP 7)."""
    paires = sorted([(dist2(Xa[i], x), i) for i in range(len(Xa))])
    return [i for (d, i) in paires[:k]]


def conduire(adj, s0, arrivee, Xa, Ya, k, n_max=40):
    """Renvoie (arrivé ?, chemin).
    En cas d'échec, le chemin finit par le coup illégal."""
    s, chemin = s0, [s0]
    for n in range(n_max):
        if dans(arrivee, (s[0], s[1])):
            return True, chemin
        x = (arrivee[0][0] - s[0], arrivee[0][1] - s[1], s[2], s[3])
        ax, ay = knn(Xa, Ya, x, k)
        t = (s[0] + s[2] + ax, s[1] + s[3] + ay, s[2] + ax, s[3] + ay)
        chemin.append(t)
        legal = False
        for u in adj[s]:
            if u == t:
                legal = True
        if not legal:
            return False, chemin           # mur, arrêt ou demi-tour
        s = t
    return False, chemin


# ---- TP 8 : les k-moyennes ----
def d2(p, q):
    """Le carré de la distance euclidienne (comme dist2, fourni)."""
    total = 0
    for i in range(len(p)):
        total = total + (p[i] - q[i]) ** 2
    return total


def kmoyennes(X, k, graine=0, n_max=100):
    """Les k-moyennes : centres de départ r.sample(range(len(X)), k) avec
    r = random.Random(graine) ; affecter (égalité : le plus petit c),
    recentrer, jusqu'à des affectations inchangées.
    Renvoie (centres, affectations, inertie, nombre de tours)."""
    r = random.Random(graine)
    centres = [X[i] for i in r.sample(range(len(X)), k)]
    aff = [-1] * len(X)
    tour = 0
    while tour < n_max:
        tour = tour + 1
        nouv = []
        for x in X:                        # affecter au centre le plus proche
            m = 0
            for c in range(1, k):          # < strict : à égalité, le plus petit c
                if d2(x, centres[c]) < d2(x, centres[m]):
                    m = c
            nouv.append(m)
        if nouv == aff:                    # plus aucun changement : c'est fini
            break
        aff = nouv
        for c in range(k):                 # recentrer : la moyenne du groupe
            somme = [0] * len(X[0])
            n = 0
            for i in range(len(X)):
                if aff[i] == c:
                    for j in range(len(X[i])):
                        somme[j] = somme[j] + X[i][j]
                    n = n + 1
            if n > 0:
                centres[c] = [s / n for s in somme]
    inertie = 0
    for i in range(len(X)):
        inertie = inertie + d2(X[i], centres[aff[i]])
    return centres, aff, inertie, tour


# ---- TP 11 : les jeux à deux joueurs ----
def attracteur(adj, arrivee):
    gagne = {}
    for s in adj:
        if dans(arrivee, (s[0], s[1])):
            gagne[(s, 1)] = True
            gagne[(s, 2)] = True
    change = True
    while change:
        change = False
        for s in adj:
            if (s, 1) not in gagne:              # J1 choisit : un coup gagnant suffit
                for t in adj[s]:
                    if (t, 2) in gagne and (s, 1) not in gagne:
                        gagne[(s, 1)] = True
                        change = True
            if (s, 2) not in gagne and len(adj[s]) > 0:   # J2 choisit : il faut que tous ses coups soient gagnants pour J1
                tous = True
                for t in adj[s]:
                    if (t, 1) not in gagne:
                        tous = False
                if tous:
                    gagne[(s, 2)] = True
                    change = True
    return gagne

def gagnants(adj, arrivee):
    rang = {}
    for s in adj:
        if dans(arrivee, (s[0], s[1])):
            rang[s] = 0
    tour = 0
    change = True
    while change:
        change = False
        tour = tour + 1
        nouveaux = []
        for s in adj:
            if s not in rang and len(adj[s]) > 0:
                n = 0
                for t in adj[s]:
                    if t in rang:
                        n = n + 1
                if n >= 2 or (n == 1 and len(adj[s]) == 1):
                    nouveaux.append(s)
        for s in nouveaux:
            rang[s] = tour
            change = True
    return rang

def proposer(adj, s, rang):
    P = []
    for t in adj[s]:
        if t in rang:
            P.append((rang[t], t))
    P = sorted(P)
    return [t for (r, t) in P[:2]]

def valeur(adj, s, k, arrivee, cpt):
    cpt[0] = cpt[0] + 1
    if dans(arrivee, (s[0], s[1])):
        return 100
    if len(adj[s]) == 0:
        return -100
    if k == 0:
        return -h(s, arrivee)
    v1, v2 = -1000, -1000                  # les deux meilleures valeurs des successeurs
    for t in adj[s]:
        v = valeur(adj, t, k - 1, arrivee, cpt)
        if v > v1:
            v1, v2 = v, v1
        elif v > v2:
            v2 = v
    if len(adj[s]) == 1:
        return v1
    return v2

def proposer_minmax(adj, s, k, arrivee, cpt):
    P = []
    for t in adj[s]:
        P.append((-valeur(adj, t, k - 1, arrivee, cpt), t))
    P = sorted(P)
    return [t for (v, t) in P[:2]]

def partie(adj, s0, arrivee, rang, k):
    s, n, cpt = s0, 0, [0]
    while not dans(arrivee, (s[0], s[1])) and n < 40:
        if len(adj[s]) == 0:
            return "J2 gagne", n, cpt[0]
        if k == 0:
            P = proposer(adj, s, rang)
        else:
            P = proposer_minmax(adj, s, k, arrivee, cpt)
        s = choisir(P, rang)
        n = n + 1
    if n == 40:
        return "nul", n, cpt[0]
    return "J1 gagne", n, cpt[0]


# ---- TP SI-1 : tester les exigences ----
def evaluer(resultats, niveau, limite):
    """Renvoie {circuit: (statut, ecart)}.
    statut : "ok" si coups <= niveau, "limite" si coups <= limite,
    "echec" sinon ou si le pilote n'arrive pas.
    ecart : coups - niveau, ou None si le pilote n'arrive pas."""
    bilan = {}
    for circuit in resultats:
        coups = resultats[circuit]
        if coups is None:                      # le pilote n'arrive pas : cas à part
            bilan[circuit] = ("echec", None)
        elif coups <= niveau:
            bilan[circuit] = ("ok", coups - niveau)
        elif coups <= limite:
            bilan[circuit] = ("limite", coups - niveau)
        else:
            bilan[circuit] = ("echec", coups - niveau)
    return bilan


def exigence_satisfaite(resultats, niveau, limite):
    """Renvoie True seulement si tous les circuits sont "ok" ou "limite"."""
    bilan = evaluer(resultats, niveau, limite)
    for circuit in bilan:
        if bilan[circuit][0] == "echec":
            return False
    return True


# ---- TP SI-2 : le modèle de la voiture ----
def pas(etat, commande):
    """Un coup du modèle : l'état suivant (x, y, vx, vy). Ne connaît pas les murs."""
    x, y, vx, vy = etat
    ax, ay = commande
    return (x + vx + ax, y + vy + ay, vx + ax, vy + ay)


def simuler(etat, commandes):
    """La liste des états, celui de départ compris : len(commandes) + 1 états."""
    etats = [etat]
    for c in commandes:
        etat = pas(etat, c)
        etats.append(etat)
    return etats


def cout_modele(chemin):
    """Le coût prévu par le modèle de départ : 1 par coup."""
    return len(chemin) - 1


def cout_modele_sable(sable, chemin, c):
    """Le coût prévu par le modèle enrichi : 1 par coup, c si le coup touche le sable."""
    total = 0
    for i in range(len(chemin) - 1):
        total = total + cout(sable, chemin[i], chemin[i + 1], c)
    return total


# ---- TP SI-3 : le pilote à deux états ----
def meilleur(coups, arrivee):
    """L'état de coups le plus proche de l'arrivée ; à égalité, le premier.
    Précondition : coups n'est pas vide."""
    m = coups[0]
    for e in coups:
        if distance((e[0], e[1]), arrivee) < distance((m[0], m[1]), arrivee):
            m = e
    return m


def danger(grille, cap, arrivee, etat, seuil):
    """Vrai si le coup glouton depuis etat laisse moins de seuil coups possibles."""
    g = meilleur(coups_possibles(grille, cap, etat), arrivee)
    return len(coups_possibles(grille, cap, g)) < seuil


def piloter(grille, depart, arrivee, cap, seuil):
    """Renvoie (statut, chemin, modes) : statut "arrive", "bloque" ou "boucle"."""
    etat = (depart[0], depart[1], 0, 0)
    chemin = [etat]
    modes = ""
    for i in range(100):
        coups = coups_possibles(grille, cap, etat)
        if len(coups) == 0:
            return "bloque", chemin, modes
        if danger(grille, cap, arrivee, etat, seuil):
            surs = []
            for e in coups:
                if len(coups_possibles(grille, cap, e)) >= seuil:
                    surs.append(e)
            if len(surs) > 0:
                etat = meilleur(surs, arrivee)
            else:
                etat = meilleur(coups, arrivee)
            modes = modes + "P"
        else:
            etat = meilleur(coups, arrivee)
            modes = modes + "R"
        chemin.append(etat)
        if dans(arrivee, (etat[0], etat[1])):
            return "arrive", chemin, modes
    return "boucle", chemin, modes


def piloter2(grille, depart, arrivee, cap, seuil):
    """Activité 5, partie 2 : piloter, avec une seule règle changée pour l'état PRUDENT :
    si le coup glouton arrive, le pilote le joue, même s'il laisse peu de coups possibles."""
    etat = (depart[0], depart[1], 0, 0)
    chemin = [etat]
    modes = ""
    for i in range(100):
        coups = coups_possibles(grille, cap, etat)
        if len(coups) == 0:
            return "bloque", chemin, modes
        if danger(grille, cap, arrivee, etat, seuil):
            g = meilleur(coups, arrivee)
            surs = []
            for e in coups:
                if len(coups_possibles(grille, cap, e)) >= seuil:
                    surs.append(e)
            if dans(arrivee, (g[0], g[1])):
                etat = g                       # la règle changée : le coup glouton, s'il arrive
            elif len(surs) > 0:
                etat = meilleur(surs, arrivee)
            else:
                etat = g
            modes = modes + "P"
        else:
            etat = meilleur(coups, arrivee)
            modes = modes + "R"
        chemin.append(etat)
        if dans(arrivee, (etat[0], etat[1])):
            return "arrive", chemin, modes
    return "boucle", chemin, modes


# ---- TP SI-4 : la boucle fermée ----
from squelette import arrondi, jouer_coup, souffler


def correcteur(etat, cible, commande_plan, kp):
    """La commande corrigée, bornée à [-1, 1]."""
    x, y, vx, vy = etat
    ax, ay = commande_plan
    ex = cible[0] - (x + vx + ax)
    ey = cible[1] - (y + vy + ay)
    return (max(-1, min(1, ax + arrondi(kp * ex))), max(-1, min(1, ay + arrondi(kp * ey))))


def boucle(grille, cap, arrivee, plan, vent, kp):
    """Renvoie (statut, chemin)."""
    etat = plan[0]
    chemin = [etat]
    for k in range(40):
        if k + 1 < len(plan):
            cible = (plan[k + 1][0], plan[k + 1][1])
            cp = (plan[k + 1][2] - plan[k][2], plan[k + 1][3] - plan[k][3])
        else:
            cible = (plan[-1][0], plan[-1][1])
            cp = (0, 0)
        a = correcteur(etat, cible, cp, kp)
        statut, etat2 = jouer_coup(grille, cap, arrivee, etat, a)
        if statut == "refus":
            return statut, chemin
        if statut != "ok":
            chemin.append(etat2)
            return statut, chemin
        sv, etat = souffler(grille, etat2, vent)
        chemin.append(etat)
        if sv == "mur":
            return "mur", chemin
    return "perdue", chemin

# ---- TP SI-4, Plus loin : le correcteur proportionnel intégral (PI) ----
# Le correcteur proportionnel laisse un écart statique d'une case sous un vent constant :
# une fois la vitesse verticale égale à -1, la prévision tombe sur le plan, l'écart vu par
# le correcteur est nul, et rien ne ramène la voiture. Le terme intégral garde la mémoire
# des écarts de POSITION mesurés (plan - mesure) et pousse jusqu'à les annuler.
def correcteur_pi(etat, cible, commande_plan, kp, ki, somme):
    """Correcteur PI avec anticipation. somme = (sx, sy) : la somme des écarts de position
    mesurés depuis le départ, coup en cours compris. Renvoie la commande bornée à [-1, 1] :
    commande du plan + arrondi(kp * écart à la prévision + ki * somme)."""
    x, y, vx, vy = etat
    ax, ay = commande_plan
    ex = cible[0] - (x + vx + ax)
    ey = cible[1] - (y + vy + ay)
    return (max(-1, min(1, ax + arrondi(kp * ex + ki * somme[0]))),
            max(-1, min(1, ay + arrondi(kp * ey + ki * somme[1]))))


def boucle_pi(grille, cap, arrivee, plan, vent, kp, ki):
    """Comme boucle, avec correcteur_pi. Renvoie (statut, chemin)."""
    etat = plan[0]
    chemin = [etat]
    sx = sy = 0
    for k in range(40):
        p = plan[min(k, len(plan) - 1)]
        sx, sy = sx + p[0] - etat[0], sy + p[1] - etat[1]       # écart de position mesuré
        if k + 1 < len(plan):
            cible = (plan[k + 1][0], plan[k + 1][1])
            cp = (plan[k + 1][2] - plan[k][2], plan[k + 1][3] - plan[k][3])
        else:
            cible = (plan[-1][0], plan[-1][1])
            cp = (0, 0)
        a = correcteur_pi(etat, cible, cp, kp, ki, (sx, sy))
        statut, etat2 = jouer_coup(grille, cap, arrivee, etat, a)
        if statut == "refus":
            return statut, chemin
        if statut != "ok":
            chemin.append(etat2)
            return statut, chemin
        sv, etat = souffler(grille, etat2, vent)
        chemin.append(etat)
        if sv == "mur":
            return "mur", chemin
    return "perdue", chemin


def demo_pi():
    """Démonstration (pas de vérification au labo) : P contre PI, kp = 1.
    1. Piste droite 30 x 11, départ (1, 5), arrivée en x = 28 (lignes 4 à 6), plan en ligne
       droite (10 coups), vent d'une case vers le bas pour x de 4 à 22.
    2. Circuit E et son vent (le plan longe le mur à une case)."""
    from squelette import lire, cap_depart, VENT
    txt = "\n".join("".join("D" if (x, y) == (1, 5) else "A" if x == 28 and 4 <= y <= 6 else "."
                             for x in range(30)) for y in range(11))
    g, d, a = lire(txt)
    cap = cap_depart(g, d, a)
    plan = [(1, 5, 0, 0)]
    for c in [(1, 0)] * 3 + [(0, 0)] * 7:
        plan.append(jouer_coup(g, cap, a, plan[-1], c)[1])
    vent = (4, 0, 22, 10, 0, 1)
    ecarts = lambda ch, P: [e[1] - P[min(k, len(P) - 1)][1] for k, e in enumerate(ch)]
    for nom, (st, ch) in (("P,  kp = 1         ", boucle(g, cap, a, plan, vent, 1)),
                          ("PI, kp = 1, ki = 0,5", boucle_pi(g, cap, a, plan, vent, 1, 0.5)),
                          ("PI, kp = 1, ki = 1  ", boucle_pi(g, cap, a, plan, vent, 1, 1))):
        print("piste droite,", nom, ":", st, len(ch) - 1, "coups, écart vertical par coup", ecarts(ch, plan))
    gE, dE, aE = lire(open("circuit_E.txt").read())
    capE = cap_depart(gE, dE, aE)
    pE = [(dE[0], dE[1], 0, 0)]                   # le plan du Stratège : plus court chemin
    pere, file = {pE[0]: None}, [pE[0]]
    while file and len(pE) == 1:
        s = file.pop(0)
        for c in ACC:
            st, t = jouer_coup(gE, capE, aE, s, c)
            if st in ("ok", "arrivee") and t not in pere:
                pere[t] = s
                if st == "arrivee":
                    ch = [t]
                    while pere[ch[-1]] is not None:
                        ch.append(pere[ch[-1]])
                    pE = ch[::-1]
                    break
                file.append(t)
    for nom, (st, ch) in (("P,  kp = 1         ", boucle(gE, capE, aE, pE, VENT["E"], 1)),
                          ("PI, kp = 1, ki = 0,5", boucle_pi(gE, capE, aE, pE, VENT["E"], 1, 0.5))):
        print("circuit E,    ", nom, ":", st, len(ch) - 1, "coups, écart vertical par coup", ecarts(ch, pE))


# ---- TP SI-5 : prédire le coût par régression ----
from squelette import charger_pistes


def statistiques(valeurs):
    """Renvoie (moyenne, écart-type) des valeurs."""
    import numpy as np
    return np.mean(valeurs), np.std(valeurs)


def ajuster(P, noms, n_app):
    """Le modèle linéaire entraîné sur les n_app premières pistes, descripteurs noms."""
    import numpy as np
    from sklearn.linear_model import LinearRegression
    X = np.column_stack([P[c][:n_app] for c in noms])
    m = LinearRegression()
    m.fit(X, P["cout"][:n_app])
    return m


def erreur_moyenne(modele, P, noms, debut, fin):
    """L'erreur absolue moyenne du modèle sur les pistes debut à fin - 1."""
    import numpy as np
    X = np.column_stack([P[c][debut:fin] for c in noms])
    return np.mean(np.abs(modele.predict(X) - P["cout"][debut:fin]))


# ---- TP SI-6 : le réseau de neurones ----
def preparer(texte, circuits):
    """(X, y) : X tableau (n, 4) des exemples des circuits, y leurs classes de 0 à 8."""
    import numpy as np
    Xa, Ya = lire_exemples(texte, circuits)
    y = [ACC.index(a) for a in Ya]
    return np.array(Xa), np.array(y)


def decouper(X, y, graine):
    """(Xa, Xt, ya, yt) : 70 % pour l'apprentissage, 30 % pour le test."""
    from sklearn.model_selection import train_test_split
    return train_test_split(X, y, test_size=0.3, random_state=graine)


def entrainer(X, y, graine):
    """Le réseau (30, 30) entraîné sur X, y."""
    from sklearn.neural_network import MLPClassifier
    m = MLPClassifier(hidden_layer_sizes=(30, 30), max_iter=3000, random_state=graine)
    m.fit(X, y)
    return m


def conduire_reseau(adj, s0, arrivee, modele, n_max=40):
    """Renvoie (arrivé ?, chemin) ; en cas d'échec, le chemin finit par le coup illégal."""
    s, chemin = s0, [s0]
    for n in range(n_max):
        if dans(arrivee, (s[0], s[1])):
            return True, chemin
        x = [[arrivee[0][0] - s[0], arrivee[0][1] - s[1], s[2], s[3]]]
        ax, ay = ACC[int(modele.predict(x)[0])]
        t = (s[0] + s[2] + ax, s[1] + s[3] + ay, s[2] + ax, s[3] + ay)
        chemin.append(t)
        if t not in adj[s]:
            return False, chemin
        s = t
    return False, chemin
