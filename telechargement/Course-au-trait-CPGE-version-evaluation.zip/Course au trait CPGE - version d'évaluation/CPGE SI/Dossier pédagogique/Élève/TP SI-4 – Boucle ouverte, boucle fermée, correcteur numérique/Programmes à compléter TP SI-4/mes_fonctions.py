"""Course au trait - TP CPGE : mes fonctions, TP SI-4.

En haut : les fonctions du tronc commun (TP 1 à 8 et 11), que le TP
réutilise si besoin (par exemple cout, coups_possibles ou lire_exemples).
En bas : les fonctions du TP SI-4, à compléter.

Complète chaque fonction : remplace la ligne « raise NotImplementedError »
par ton code : celui des TP 1 à 8 et 11, puis celui du TP SI-4.
Un état est un quadruplet (x, y, vx, vy).
Les fiches donnent, dans l'encadré « Python utile », la documentation
des éléments hors programme (None, deque, heapq, random...).
"""
import heapq
import random
from collections import deque
from squelette import ACC, segment_libre, touche, dans, lire, cap_depart


# ---- TP 1 : les coups permis et le glouton ----
def distance(p, arrivee):
    """La distance du point p à la case d'arrivée la plus proche
    (0 si p est sur une case d'arrivée, bord compris)."""
    raise NotImplementedError("distance")


def coups_possibles(grille, cap, etat):
    """La liste des états atteignables en un coup depuis etat (ordre de ACC).
    Interdits : s'arrêter ; faire demi-tour (produit scalaire < 0) ;
    au départ, partir à l'opposé du cap (produit scalaire avec cap <= 0) ;
    toucher un mur ou le bord (segment_libre).
    TP 5 : sur un circuit sans solution, cap vaut None."""
    raise NotImplementedError("coups_possibles")


def glouton(grille, depart, arrivee, cap):
    """Le Fonceur de profondeur 1 : à chaque coup, l'état suivant le plus
    proche de l'arrivée (à égalité, le premier dans l'ordre de ACC).
    Renvoie (statut, liste des états), statut = "arrive", "bloque" (aucun
    coup légal) ou "boucle" (garde-fou : 100 coups)."""
    raise NotImplementedError("glouton")


# ---- TP 2 : le graphe des états et le parcours en largeur ----
def construire(grille, depart, arrivee, cap):
    """Le graphe des états : dictionnaire état -> liste des états suivants.
    Parcours en largeur depuis (départ, vitesse nulle) ;
    un état d'arrivée n'a pas de suivant."""
    raise NotImplementedError("construire")


def remonter(pere, s):
    """Le chemin du départ jusqu'à s, en remontant les pères (fourni)."""
    chemin = []
    while s is not None:
        chemin = [s] + chemin
        s = pere[s]
    return chemin


def largeur(adj, s0, arrivee):
    """Le Stratège : parcours en largeur (une file) depuis s0, jusqu'au premier
    état d'arrivée découvert.
    Précondition : adj contient s0 et tous les états qu'on atteint depuis s0.
    Postcondition : renvoie (n, chemin, découverts) ; chemin va de s0 à une
    arrivée en n coups, le moins possible ; (None, [], découverts) sans solution."""
    raise NotImplementedError("largeur")


def profondeur(adj, s0, arrivee):
    """Comme largeur, avec une pile (append et pop()) : les successeurs sont
    empilés dans l'ordre de coups_possibles. Même résultat renvoyé."""
    raise NotImplementedError("profondeur")


# ---- TP 3 : les coûts et Dijkstra ----
def cases_sable(grille):
    """La liste des cases de sable, en rectangles (x, y, x + 1, y + 1)."""
    raise NotImplementedError("cases_sable")


def cout(sable, s, t, c):
    """Le coût du coup de s à t : c s'il touche du sable (touche), 1 sinon."""
    raise NotImplementedError("cout")


def cout_chemin(sable, chemin, c):
    """Le coût total d'un chemin (fourni)."""
    total = 0
    for i in range(len(chemin) - 1):
        total = total + cout(sable, chemin[i], chemin[i + 1], c)
    return total


def dijkstra(sable, adj, s0, arrivee, c):
    """Le Stratège pondéré : Dijkstra, tas (heapq) de couples (distance, état).
    Renvoie (coût, chemin, nombre d'états fixés, nombre d'états découverts)."""
    raise NotImplementedError("dijkstra")


# ---- TP 4 : l'heuristique cinématique et A* ----
def coups_min_1d(lo, hi, v):
    """Le plus petit nombre de coups n pour qu'une vitesse v puisse amener
    dans l'intervalle [lo, hi] sur un axe."""
    raise NotImplementedError("coups_min_1d")


def h(etat, arrivee):
    """L'heuristique cinématique : le plus petit nombre de coups pour
    atteindre une case d'arrivée en ignorant les murs (le maximum des
    deux axes, le minimum sur les cases d'arrivée)."""
    raise NotImplementedError("h")


def vol(etat, arrivee):
    """La distance à vol d'oiseau : distance((x, y), arrivee) du
    TP 1, utilisée comme heuristique (celle du Fonceur)."""
    raise NotImplementedError("vol")


def astar(sable, adj, s0, arrivee, c, hf):
    """A* : comme Dijkstra, avec dans le tas des triplets
    (distance + hf(état, arrivee), distance, état).
    Renvoie (coût, chemin, nombre d'états fixés, nombre d'états découverts)."""
    raise NotImplementedError("astar")


# ---- TP 5 : spécifier, tester, comparer à un oracle ----
def mes_tests(dijkstra):
    """Tes tests de dijkstra, avec assert (activité 2). Le labo appelle
    mes_tests avec la vraie dijkstra, puis avec six versions fausses : chaque
    version fausse doit faire échouer au moins un assert, la vraie aucun.
    Exemple : lire le circuit DA, construire son graphe, puis
    assert dijkstra(sable, adj, s0, arrivee, 3)[0] == 1"""
    raise NotImplementedError("mes_tests")


def alea(graine, L=12, H=7, p_mur=0.08, p_sable=0.15):
    """Un circuit aléatoire, en grille texte lisible par lire (activité 3).
    r = random.Random(graine) ; pour chaque case, ligne par ligne, u = r.random() :
    mur "#" si u < p_mur, sable "s" si u < p_mur + p_sable, sinon ".".
    Puis D en (1, H // 2) et A en (L - 2, H // 2) ; chaque ligne finit par "\n"."""
    raise NotImplementedError("alea")


def oracle(sable, adj, s0, arrivee, c):
    """Le programme de référence (activité 3) : le plus petit coût pour atteindre
    l'arrivée (None si elle est inaccessible), écrit autrement que dijkstra :
    une file (deque) et des distances corrigées tant qu'elles baissent."""
    raise NotImplementedError("oracle")


# ---- TP 6 : la programmation dynamique ----
INF = float("inf")


def reste_naif(sable, adj, s, k, arrivee, c, cpt):
    """R(s, k) : le plus petit coût pour finir depuis s en au plus k coups
    (INF si impossible), sans mémo. cpt[0] compte les appels (+1 en entrant)."""
    raise NotImplementedError("reste_naif")


def reste(sable, adj, s, k, arrivee, c, memo, cpt):
    """Comme reste_naif, avec le dictionnaire memo[(s, k)] : on y range
    chaque valeur calculée (pas les cas de base : arrivée, k = 0)."""
    raise NotImplementedError("reste")


def reconstruire(sable, adj, s, k, arrivee, c, memo):
    """Le trajet de coût R(s, k) : à chaque coup, le premier successeur t
    (ordre de adj[s]) tel que cout(s, t) + R(t, k - 1) = R(s, k)."""
    raise NotImplementedError("reconstruire")


# ---- TP 7 : les k plus proches voisins ----
def lire_exemples(texte, circuits=None):
    """Lit un jeu d'exemples exporté par le labo (fourni) : (Xa, Ya).
    circuits : les lettres des circuits à garder ("ABC"), tous si None."""
    Xa, Ya = [], []
    lignes = texte.split("\n")
    for ligne in lignes[1:]:                   # la ligne 0 est l'en-tête
        champs = ligne.split(";")
        garder = len(champs) >= 6
        if garder and circuits is not None and len(champs) > 6:
            garder = champs[6].split()[1] in circuits    # « Circuit A » -> A
        if garder:
            Xa.append((int(champs[0]), int(champs[1]), int(champs[2]), int(champs[3])))
            Ya.append((int(champs[4]), int(champs[5])))
    return Xa, Ya


def dist2(p, q):
    """Le carré de la distance euclidienne (fourni)."""
    total = 0
    for i in range(len(p)):
        total = total + (p[i] - q[i]) ** 2
    return total


def knn(Xa, Ya, x, k):
    """Le vote des k plus proches voisins de x.
    Égalité de distance : le plus petit indice d'abord.
    Égalité de votes : l'étiquette du voisin le plus proche."""
    raise NotImplementedError("knn")


def conduire(adj, s0, arrivee, Xa, Ya, k, n_max=40):
    """Voisins conduit depuis s0 : à chaque coup, l'accélération votée par
    knn sur le vecteur (dx, dy, vx, vy), où (dx, dy) va de la voiture au
    coin haut-gauche de la première case d'arrivée.
    Renvoie (arrivé ?, chemin) ; en cas d'échec, le chemin finit par le
    coup illégal."""
    raise NotImplementedError("conduire")


# ---- TP 8 : les k-moyennes ----
def d2(p, q):
    """Le carré de la distance euclidienne (comme dist2, fourni)."""
    total = 0
    for i in range(len(p)):
        total = total + (p[i] - q[i]) ** 2
    return total


def kmoyennes(X, k, graine=0, n_max=100):
    """Les k-moyennes : centres de départ r.sample(range(len(X)), k) avec
    r = random.Random(graine) ; affecter (égalité : le plus petit c),
    recentrer, jusqu'à des affectations inchangées.
    Renvoie (centres, affectations, inertie, nombre de tours)."""
    raise NotImplementedError("kmoyennes")


# ---- TP 11 : les jeux à deux joueurs ----
def attracteur(adj, arrivee):
    """Un coup sur deux : les positions (s, j) gagnantes pour J1, où j (1 ou 2)
    est le joueur qui doit jouer. Renvoie un dictionnaire {(s, j): True}."""
    raise NotImplementedError("attracteur")


def gagnants(adj, arrivee):
    """Je propose, tu choisis : le rang de chaque état gagnant pour J1
    (0 à l'arrivée). Renvoie un dictionnaire {état: rang}."""
    raise NotImplementedError("gagnants")


def proposer(adj, s, rang):
    """La stratégie de J1 : les deux successeurs gagnants de plus petit rang
    (égalité : le plus petit état). Renvoie la liste des états proposés."""
    raise NotImplementedError("proposer")


def valeur(adj, s, k, arrivee, cpt):
    """La valeur minmax de s quand J1 doit proposer et regarde k coups devant :
    100 à l'arrivée, -100 bloqué, -h(s, arrivee) si k vaut 0.
    cpt[0] augmente de 1 à chaque appel."""
    raise NotImplementedError("valeur")


def proposer_minmax(adj, s, k, arrivee, cpt):
    """Les deux successeurs de plus grande valeur (k - 1 coups devant)."""
    raise NotImplementedError("proposer_minmax")


def partie(adj, s0, arrivee, rang, k):
    """Une partie contre l'adversaire parfait choisir : J1 joue proposer si
    k vaut 0, proposer_minmax sinon. Renvoie (issue, coups, appels), issue
    valant "J1 gagne", "J2 gagne" ou "nul" (40 coups)."""
    raise NotImplementedError("partie")


# ---- TP SI-4 : la boucle fermée ----
from squelette import arrondi, jouer_coup, souffler   # fournies


def correcteur(etat, cible, commande_plan, kp):
    """La commande corrigée, chaque composante bornée à [-1, 1].
    etat = (x, y, vx, vy) : ce que la voiture mesure.
    cible = (x, y) : la position du plan au coup suivant.
    commande_plan = (ax, ay) : la commande du plan pour ce coup.
    Prévision sans correction : (x + vx + ax, y + vy + ay) ; écart = cible - prévision.
    Renvoie (ax + arrondi(kp * écart en x), ay + arrondi(kp * écart en y)), bornée."""
    raise NotImplementedError


def boucle(grille, cap, arrivee, plan, vent, kp):
    """Fait rouler la voiture en suivant le plan (la liste des états du Stratège).
    À chaque coup k : cible = position de plan[k + 1], commande du plan = vitesse de plan[k + 1]
    moins vitesse de plan[k] ; une fois le plan fini : la dernière position et (0, 0).
    Puis : commande = correcteur(...), jouer_coup, souffler. kp = 0 : la boucle ouverte.
    Arrêt à l'arrivée, au mur, sur un refus, ou après 40 coups (statut "perdue").
    Renvoie (statut, chemin) : chemin = les états après le vent, celui de départ compris
    (un refus n'ajoute rien ; un mur ajoute l'état qui touche le mur)."""
    raise NotImplementedError
