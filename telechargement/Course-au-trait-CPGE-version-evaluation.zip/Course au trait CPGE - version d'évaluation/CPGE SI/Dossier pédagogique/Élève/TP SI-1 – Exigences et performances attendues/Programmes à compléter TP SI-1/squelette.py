"""Course au trait - TP CPGE : le squelette fourni.

Ces fonctions appliquent exactement les règles du moteur du jeu.
Ne les modifie pas : le labo refuserait une trajectoire calculée
avec d'autres règles.

Coordonnées : celles des fiches. La case de la colonne x et de la
ligne y occupe le carré de (x, y) à (x + 1, y + 1).
La voiture se pose sur les coins des cases.
"""

# les 9 accélérations, dans l'ordre du jeu
ACC = [(ax, ay) for ay in (-1, 0, 1) for ax in (-1, 0, 1)]

# les caps de départ des circuits A, B et C (TP 1)
CAPS = {"A": (1, -1), "B": (1, -1), "C": (1, 0)}


def lire(texte):
    """Lit une grille (circuit.txt ou fichier de remise) : renvoie
    (grille, depart, arrivee), arrivee = rectangles (x0, y0, x1, y1)."""
    lignes = texte.replace("\r", "").split("\n")
    for i, ligne in enumerate(lignes):     # remise : la grille suit « grille : »
        if ligne.strip().lower().startswith("grille"):
            lignes = lignes[i + 1:]
            break
    lignes = [l.rstrip() for l in lignes if l.strip()]
    largeur = max(len(l) for l in lignes)
    grille = [l.ljust(largeur, "#") for l in lignes]
    depart, arrivee = None, []
    for y, ligne in enumerate(grille):
        for x, car in enumerate(ligne):
            if car not in "#.sDA":
                raise ValueError("caractère inconnu « %s » ligne %d" % (car, y + 1))
            if car == "D":
                depart = (x, y)
            elif car == "A":
                arrivee.append((x, y, x + 1, y + 1))
    if depart is None or not arrivee:
        raise ValueError("il manque le départ D ou l'arrivée A")
    return grille, depart, arrivee


def touche(p, q, r):
    """Le segment de p à q touche-t-il le rectangle fermé r = (x0, y0, x1, y1) ?
    Même calcul que le jeu (Liang-Barsky) : toucher le bord compte."""
    t0, t1 = 0.0, 1.0
    dx, dy = q[0] - p[0], q[1] - p[1]
    for pp, qq in ((-dx, p[0] - r[0]), (dx, r[2] - p[0]),
                   (-dy, p[1] - r[1]), (dy, r[3] - p[1])):
        if pp == 0:
            if qq < 0:
                return False
        else:
            t = qq / pp
            if pp < 0:
                if t > t1:
                    return False
                t0 = max(t0, t)
            else:
                if t < t0:
                    return False
                t1 = min(t1, t)
    return True


def segment_libre(grille, p, q):
    """Le segment de p à q ne touche-t-il ni mur ni bord ?
    Tout ce qui est hors de la grille est un mur."""
    h, l = len(grille), len(grille[0])
    xmin, xmax = min(p[0], q[0]), max(p[0], q[0])
    ymin, ymax = min(p[1], q[1]), max(p[1], q[1])
    if xmin <= 0 or ymin <= 0 or xmax >= l or ymax >= h:
        return False                       # le bord de la grille est un mur
    for y in range(max(0, int(ymin) - 1), min(h, int(ymax) + 1)):
        for x in range(max(0, int(xmin) - 1), min(l, int(xmax) + 1)):
            if grille[y][x] == "#" and touche(p, q, (x, y, x + 1, y + 1)):
                return False
    return True


def dans(arrivee, p):
    """Le point p est-il sur une case d'arrivée (bord compris) ?"""
    return any(r[0] <= p[0] <= r[2] and r[1] <= p[1] <= r[3] for r in arrivee)


def cap_depart(grille, depart, arrivee):
    """Le cap de départ, calculé comme le jeu : la vitesse du 1er coup du plus
    court chemin (largeur, ordre de ACC). None s'il n'y a aucun chemin."""
    s0 = (depart[0], depart[1], 0, 0)
    vus, couche = {s0}, [(s0, None)]
    for _ in range(60):
        suivante = []
        for (x, y, vx, vy), premier in couche:
            for ax, ay in ACC:
                nvx, nvy = vx + ax, vy + ay
                if (nvx, nvy) == (0, 0):
                    continue                   # interdit de s'arrêter
                if (vx, vy) != (0, 0) and nvx * vx + nvy * vy < 0:
                    continue                   # demi-tour
                if not segment_libre(grille, (x, y), (x + nvx, y + nvy)):
                    continue
                t = (x + nvx, y + nvy, nvx, nvy)
                p = premier or (nvx, nvy)
                if dans(arrivee, (t[0], t[1])):
                    return p
                if t not in vus:
                    vus.add(t)
                    suivante.append((t, p))
        if not suivante:
            return None
        couche = suivante
    return None


def circuit_vide(l, h, r, r2):
    """Le texte d'un circuit vide de l colonnes sur h lignes : départ en
    (1, r), arrivée en (l - 2, r2) (TP 1, activité 5). À lire avec lire."""
    def car(x, y):
        return "D" if (x, y) == (1, r) else "A" if (x, y) == (l - 2, r2) else "."
    return "\n".join("".join(car(x, y) for x in range(l)) for y in range(h))


def minimum(grille, depart, arrivee, cap):
    """Le minimum absolu de coups, par un parcours en largeur (étudié en
    TP 2). None s'il n'y a aucun chemin."""
    s0 = (depart[0], depart[1], 0, 0)
    vus, couche = {s0}, [s0]
    for n in range(1, 100):
        suivante = []
        for x, y, vx, vy in couche:
            for ax, ay in ACC:
                nvx, nvy = vx + ax, vy + ay
                if (nvx, nvy) == (0, 0):
                    continue                   # interdit de s'arrêter
                if (vx, vy) == (0, 0):
                    if cap is not None and nvx * cap[0] + nvy * cap[1] <= 0:
                        continue               # mauvais cap au départ
                elif nvx * vx + nvy * vy < 0:
                    continue                   # demi-tour
                if not segment_libre(grille, (x, y), (x + nvx, y + nvy)):
                    continue
                t = (x + nvx, y + nvy, nvx, nvy)
                if dans(arrivee, (t[0], t[1])):
                    return n
                if t not in vus:
                    vus.add(t)
                    suivante.append(t)
        if not suivante:
            return None
        couche = suivante
    return None


def trajectoire(chemin):
    """Le texte à coller dans le labo : la liste des positions [(x, y), ...]."""
    return "[" + ", ".join("(%d, %d)" % (e[0], e[1]) for e in chemin) + "]"


def verifier(chemin, etats=None, circuit=None, methode=None, sable=None):
    """Fait vérifier la trajectoire par le labo, qui la rejoue avec les règles
    du jeu. etats : le compteur d'états (fixés ou découverts).
    circuit : le nom du circuit ("A", "B"…) quand le programme en parcourt
    plusieurs ; methode : "largeur", "dijkstra"… ; sable : le coût du sable
    (3 si on ne le précise pas). Hors du labo, la trajectoire est affichée."""
    texte = trajectoire(chemin)
    try:
        from js import labo                # seulement dans le labo
    except ImportError:
        fin = "" if etats is None else "| états fixés : %d" % etats
        print("Trajectoire :", texte, fin)
        return
    labo.verifier(texte, -1 if etats is None else int(etats), circuit or "",
                  methode or "", sable)


def annoncer(circuit, nom, valeur):
    """Donne un résultat au labo, qui le compare au sien :
    annoncer("A", "sommets", len(adj)). Hors du labo, il est affiché."""
    try:
        from js import labo                # seulement dans le labo
    except ImportError:
        print(circuit, ":", nom, "=", valeur)
        return
    labo.annoncer(str(circuit), str(nom), valeur)


def choisir(P, rang):
    """L'adversaire parfait du TP 11 (fourni) : parmi les coups
    proposés P, un coup perdant pour J1 s'il y en a un, sinon celui de
    plus grand rang."""
    pire = P[0]
    for t in P:
        if t not in rang:
            return t
        if rang[t] > rang[pire]:
            pire = t
    return pire


# ---- Option SI : fonctions fournies ----
def arrondi(x):
    """SI-4 : l'entier le plus proche de x, le demi-entier allant vers le haut
    (round de Python ne le fait pas : round(0.5) vaut 0)."""
    import math
    return int(math.floor(x + 0.5))


def perturbation(k, rafale):
    """SI-4 : la valeur ajoutée à la vitesse au coup k (le premier coup est k = 0).
    rafale : "aucune", "un sur deux" (les coups k impairs) ou "tous"."""
    if rafale == "tous" or (rafale == "un sur deux" and k % 2 == 1):
        return -1
    return 0


def charger_pistes(nom="pistes_exemples.csv"):
    """SI-5 : lit le fichier des pistes et renvoie un dictionnaire de tableaux
    numpy, un par colonne : P["L"], P["murs"], P["cout"]..."""
    import numpy as np
    lignes = [l for l in open(nom).read().replace("\r", "").split("\n") if l.strip()]
    noms = lignes[0].split(";")
    valeurs = [[float(v) for v in l.split(";")] for l in lignes[1:]]
    return {n: np.array([v[i] for v in valeurs]) for i, n in enumerate(noms)}


# SI-4 : le vent sur le circuit E (l'épingle) : zone x de 4 à 14, y de 4 à 8, décalage d'une case vers le bas
VENT = {"E": (4, 4, 14, 8, 0, 1)}

def jouer_coup(grille, cap, arrivee, etat, commande):
    """SI-4 : joue un coup avec les règles du jeu.
    Renvoie (statut, nouvel_etat) ; statut : "ok", "arrivee", "mur" ou "refus"
    (commande hors de -1, 0, +1, arrêt, demi-tour ou mauvais cap au départ)."""
    x, y, vx, vy = etat
    ax, ay = commande
    if abs(ax) > 1 or abs(ay) > 1:
        return "refus", etat
    nvx, nvy = vx + ax, vy + ay
    if (nvx, nvy) == (0, 0):
        return "refus", etat
    if (vx, vy) == (0, 0):
        if cap is not None and nvx * cap[0] + nvy * cap[1] <= 0:
            return "refus", etat
    elif nvx * vx + nvy * vy < 0:
        return "refus", etat
    t = (x + nvx, y + nvy, nvx, nvy)
    if not segment_libre(grille, (x, y), (t[0], t[1])):
        return "mur", t
    if dans(arrivee, (t[0], t[1])):
        return "arrivee", t
    return "ok", t


def souffler(grille, etat, vent):
    """SI-4 : le vent. vent = (x0, y0, x1, y1, dx, dy), ou None s'il n'y a pas de vent.
    Si la voiture est dans la zone (bords compris), le vent la décale de (dx, dy).
    Renvoie (statut, etat) ; statut : "calme", "poussee" ou "mur" (poussée contre un mur)."""
    if vent is None:
        return "calme", etat
    x0, y0, x1, y1, dx, dy = vent
    x, y, vx, vy = etat
    if not (x0 <= x <= x1 and y0 <= y <= y1):
        return "calme", etat
    t = (x + dx, y + dy, vx, vy)
    if not segment_libre(grille, (x, y), (t[0], t[1])):
        return "mur", t
    return "poussee", t

