-- TP 9 : la base des courses — requêtes à écrire
-- À coller une par une dans le labo (activités 2 à 5, « Mes requêtes »).

-- Q2.1 (activité 2) — notions : WHERE, ORDER BY
-- Les courses arrivées sur A (sable 3) qui ont découvert des états, de celle qui en découvre le
-- moins à celle qui en découvre le plus : pilote, coups, coût, états.
-- Ta requête :


-- Q2.2 (activité 2) — notions : ORDER BY, LIMIT
-- Les 3 courses arrivées les plus courtes sur C (sable 3), à égalité dans l'ordre des pilotes :
-- pilote, coups.
-- Ta requête :


-- Q2.3 (activité 2) — notions : DISTINCT
-- Les circuits sur lesquels au moins une course n'est pas arrivée.
-- Ta requête :


-- Q2.4 (activité 2) — notions : calcul, AS
-- Les courses arrivées (sable 3) qui ont payé le sable : numéro, pilote, circuit, surcoût = coût
-- − coups.
-- Ta requête :


-- Q3.1 (activité 3) — notions : jointure
-- Pour chaque course qui n'arrive pas (sable 3, circuit N exclu) : nom du pilote, nom du circuit,
-- coups joués.
-- Ta requête :


-- Q3.2 (activité 3) — notions : autojointure
-- Les circuits où A* « vol d'oiseau » paie plus cher que Dijkstra (sable 3) : circuit, coût de
-- Dijkstra, coût de A* vol d'oiseau.
-- Ta requête :


-- Q3.3 (activité 3) — notions : jointure, tri
-- Le trajet de la Profondeur sur S (sable 3), position par position : rang, x, y, vx, vy.
-- Ta requête :


-- Q4.1 (activité 4) — notions : GROUP BY, COUNT
-- Pour chaque pilote, le nombre de courses arrivées au sable 3.
-- Ta requête :


-- Q4.2 (activité 4) — notions : GROUP BY, MIN
-- Pour chaque circuit, le plus petit coût obtenu par une course arrivée (sable 3).
-- Ta requête :


-- Q4.3 (activité 4) — notions : HAVING
-- Les pilotes arrivés sur les 7 circuits qui ont une solution (sable 3).
-- Ta requête :


-- Q4.4 (activité 4) — notions : requête imbriquée
-- Les courses optimales (sable 3) : celles dont le coût égale le plus petit coût de leur circuit.
-- Circuit, pilote, coût.
-- Ta requête :


-- Q5.1 (activité 5) — notions : EXCEPT
-- Les circuits où Dijkstra arrive mais pas le Fonceur de profondeur 1 (sable 3).
-- Ta requête :


-- Q5.2 (activité 5) — notions : autojointure, tri
-- Sur S et T, pour chaque coût du sable : circuit, sable, coût du Stratège (largeur), coût de
-- Dijkstra, dans cet ordre.
-- Ta requête :

