# TP 10, étape 7 : la course sur le circuit de la clé
# Le labo donne le circuit de la clé dans le fichier circuit.txt.
# Choisis ta catégorie sur la ligne CATEGORIE et la même dans « Ma catégorie »
# (à gauche de la fenêtre), puis « Lancer ».

from squelette import lire, cap_depart, verifier
from mes_fonctions import construire, cases_sable, astar, h, lire_exemples, conduire

CATEGORIE = "exact"     # "exact", "rapide" ou "appris"
BUDGET = 300            # catégorie Rapide : le budget affiché par le labo à l'ouverture du circuit
SABLE = 3               # coût d'un coup qui touche du sable

grille, depart, arrivee = lire(open("circuit.txt").read())
adj = construire(grille, depart, arrivee, cap_depart(grille, depart, arrivee))
s0 = (depart[0], depart[1], 0, 0)
sable = cases_sable(grille)

if CATEGORIE == "exact":
    # le coût minimal, garanti : A* avec h (admissible) fixe moins d'états que Dijkstra
    cout, chemin, fixes, decouverts = astar(sable, adj, s0, arrivee, SABLE, h)
    print("Exact (A* avec h) : coût", cout, "en", len(chemin) - 1, "coups,", fixes, "états fixés")
    verifier(chemin, fixes, methode="astar")

elif CATEGORIE == "rapide":
    # A* avec un poids w : on garde le meilleur coût qui tient dans le budget
    meilleur = None
    for w in [1, 1.1, 1.2, 1.25, 1.3, 1.5, 2, 3]:
        def hw(e, a):
            return w * h(e, a)
        cout, chemin, fixes, decouverts = astar(sable, adj, s0, arrivee, SABLE, hw)
        dans_budget = fixes <= BUDGET
        print("w =", w, ": coût", cout, ",", fixes, "états fixés", "(dans le budget)" if dans_budget else "(hors budget)")
        if dans_budget and cout is not None and (meilleur is None or cout < meilleur[0] or (cout == meilleur[0] and fixes < meilleur[2])):
            meilleur = (cout, chemin, fixes, w)
    if meilleur is None:
        print("Aucun poids ne tient dans le budget.")
    else:
        cout, chemin, fixes, w = meilleur
        print("Rapide : je garde w =", w, ", coût", cout, "en", fixes, "états fixés")
        verifier(chemin, fixes, methode="astar")

else:
    # Voisins appris sur A, B, C, S et T, sans jamais voir ce circuit
    Xa, Ya = lire_exemples(open("exemples_entrainement.csv").read())
    for k in [1, 5, 9]:
        arrive, chemin = conduire(adj, s0, arrivee, Xa, Ya, k)
        print("k =", k, ":", "arrivé en %d coups" % (len(chemin) - 1) if arrive else "sort au coup %d" % (len(chemin) - 1))
    verifier(chemin, methode="voisins")
