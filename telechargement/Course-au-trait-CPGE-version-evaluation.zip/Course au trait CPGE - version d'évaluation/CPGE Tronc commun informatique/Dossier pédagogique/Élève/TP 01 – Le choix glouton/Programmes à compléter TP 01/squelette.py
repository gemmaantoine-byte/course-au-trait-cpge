"""Course au trait - TP CPGE : le squelette fourni.

Ces fonctions appliquent exactement les règles du moteur du jeu.
Ne les modifie pas : le labo refuserait une trajectoire calculée
avec d'autres règles.

Coordonnées : celles des fiches. La case de la colonne x et de la
ligne y occupe le carré de (x, y) à (x + 1, y + 1).
La voiture se pose sur les coins des cases.
"""

# les 9 accélérations, dans l'ordre du jeu
ACC = [(ax, ay) for ay in (-1, 0, 1) for ax in (-1, 0, 1)]

# les caps de départ des circuits A, B et C (TP 1)
CAPS = {"A": (1, -1), "B": (1, -1), "C": (1, 0)}


def lire(texte):
    """Lit une grille (circuit.txt ou fichier de remise) : renvoie
    (grille, depart, arrivee), arrivee = rectangles (x0, y0, x1, y1)."""
    lignes = texte.replace("\r", "").split("\n")
    for i, ligne in enumerate(lignes):     # remise : la grille suit « grille : »
        if ligne.strip().lower().startswith("grille"):
            lignes = lignes[i + 1:]
            break
    lignes = [l.rstrip() for l in lignes if l.strip()]
    largeur = max(len(l) for l in lignes)
    grille = [l.ljust(largeur, "#") for l in lignes]
    depart, arrivee = None, []
    for y, ligne in enumerate(grille):
        for x, car in enumerate(ligne):
            if car not in "#.sDA":
                raise ValueError("caractère inconnu « %s » ligne %d" % (car, y + 1))
            if car == "D":
                depart = (x, y)
            elif car == "A":
                arrivee.append((x, y, x + 1, y + 1))
    if depart is None or not arrivee:
        raise ValueError("il manque le départ D ou l'arrivée A")
    return grille, depart, arrivee


def touche(p, q, r):
    """Le segment de p à q touche-t-il le rectangle fermé r = (x0, y0, x1, y1) ?
    Même calcul que le jeu (Liang-Barsky) : toucher le bord compte."""
    t0, t1 = 0.0, 1.0
    dx, dy = q[0] - p[0], q[1] - p[1]
    for pp, qq in ((-dx, p[0] - r[0]), (dx, r[2] - p[0]),
                   (-dy, p[1] - r[1]), (dy, r[3] - p[1])):
        if pp == 0:
            if qq < 0:
                return False
        else:
            t = qq / pp
            if pp < 0:
                if t > t1:
                    return False
                t0 = max(t0, t)
            else:
                if t < t0:
                    return False
                t1 = min(t1, t)
    return True


def segment_libre(grille, p, q):
    """Le segment de p à q ne touche-t-il ni mur ni bord ?
    Tout ce qui est hors de la grille est un mur."""
    h, l = len(grille), len(grille[0])
    xmin, xmax = min(p[0], q[0]), max(p[0], q[0])
    ymin, ymax = min(p[1], q[1]), max(p[1], q[1])
    if xmin <= 0 or ymin <= 0 or xmax >= l or ymax >= h:
        return False                       # le bord de la grille est un mur
    for y in range(max(0, int(ymin) - 1), min(h, int(ymax) + 1)):
        for x in range(max(0, int(xmin) - 1), min(l, int(xmax) + 1)):
            if grille[y][x] == "#" and touche(p, q, (x, y, x + 1, y + 1)):
                return False
    return True


def dans(arrivee, p):
    """Le point p est-il sur une case d'arrivée (bord compris) ?"""
    return any(r[0] <= p[0] <= r[2] and r[1] <= p[1] <= r[3] for r in arrivee)


def cap_depart(grille, depart, arrivee):
    """Le cap de départ, calculé comme le jeu : la vitesse du 1er coup du plus
    court chemin (largeur, ordre de ACC). None s'il n'y a aucun chemin."""
    s0 = (depart[0], depart[1], 0, 0)
    vus, couche = {s0}, [(s0, None)]
    for _ in range(60):
        suivante = []
        for (x, y, vx, vy), premier in couche:
            for ax, ay in ACC:
                nvx, nvy = vx + ax, vy + ay
                if (nvx, nvy) == (0, 0):
                    continue                   # interdit de s'arrêter
                if (vx, vy) != (0, 0) and nvx * vx + nvy * vy < 0:
                    continue                   # demi-tour
                if not segment_libre(grille, (x, y), (x + nvx, y + nvy)):
                    continue
                t = (x + nvx, y + nvy, nvx, nvy)
                p = premier or (nvx, nvy)
                if dans(arrivee, (t[0], t[1])):
                    return p
                if t not in vus:
                    vus.add(t)
                    suivante.append((t, p))
        if not suivante:
            return None
        couche = suivante
    return None


def circuit_vide(l, h, r, r2):
    """Le texte d'un circuit vide de l colonnes sur h lignes : départ en
    (1, r), arrivée en (l - 2, r2) (TP 1, activité 5). À lire avec lire."""
    def car(x, y):
        return "D" if (x, y) == (1, r) else "A" if (x, y) == (l - 2, r2) else "."
    return "\n".join("".join(car(x, y) for x in range(l)) for y in range(h))


def minimum(grille, depart, arrivee, cap):
    """Le minimum absolu de coups, par un parcours en largeur (étudié en
    TP 2). None s'il n'y a aucun chemin."""
    s0 = (depart[0], depart[1], 0, 0)
    vus, couche = {s0}, [s0]
    for n in range(1, 100):
        suivante = []
        for x, y, vx, vy in couche:
            for ax, ay in ACC:
                nvx, nvy = vx + ax, vy + ay
                if (nvx, nvy) == (0, 0):
                    continue                   # interdit de s'arrêter
                if (vx, vy) == (0, 0):
                    if cap is not None and nvx * cap[0] + nvy * cap[1] <= 0:
                        continue               # mauvais cap au départ
                elif nvx * vx + nvy * vy < 0:
                    continue                   # demi-tour
                if not segment_libre(grille, (x, y), (x + nvx, y + nvy)):
                    continue
                t = (x + nvx, y + nvy, nvx, nvy)
                if dans(arrivee, (t[0], t[1])):
                    return n
                if t not in vus:
                    vus.add(t)
                    suivante.append(t)
        if not suivante:
            return None
        couche = suivante
    return None


def trajectoire(chemin):
    """Le texte à coller dans le labo : la liste des positions [(x, y), ...]."""
    return "[" + ", ".join("(%d, %d)" % (e[0], e[1]) for e in chemin) + "]"


def verifier(chemin, etats=None, circuit=None, methode=None, sable=None):
    """Fait vérifier la trajectoire par le labo, qui la rejoue avec les règles
    du jeu. etats : le compteur d'états (fixés ou découverts).
    circuit : le nom du circuit ("A", "B"…) quand le programme en parcourt
    plusieurs ; methode : "largeur", "dijkstra"… ; sable : le coût du sable
    (3 si on ne le précise pas). Hors du labo, la trajectoire est affichée."""
    texte = trajectoire(chemin)
    try:
        from js import labo                # seulement dans le labo
    except ImportError:
        fin = "" if etats is None else "| états fixés : %d" % etats
        print("Trajectoire :", texte, fin)
        return
    labo.verifier(texte, -1 if etats is None else int(etats), circuit or "",
                  methode or "", sable)


def annoncer(circuit, nom, valeur):
    """Donne un résultat au labo, qui le compare au sien :
    annoncer("A", "sommets", len(adj)). Hors du labo, il est affiché."""
    try:
        from js import labo                # seulement dans le labo
    except ImportError:
        print(circuit, ":", nom, "=", valeur)
        return
    labo.annoncer(str(circuit), str(nom), valeur)


def choisir(P, rang):
    """L'adversaire parfait du TP 11 (fourni) : parmi les coups
    proposés P, un coup perdant pour J1 s'il y en a un, sinon celui de
    plus grand rang."""
    pire = P[0]
    for t in P:
        if t not in rang:
            return t
        if rang[t] > rang[pire]:
            pire = t
    return pire
