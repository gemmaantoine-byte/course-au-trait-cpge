"""Course au trait - TP CPGE : mes_fonctions.py, état du fichier à la fin du TP 5.

Les fonctions déjà vues sont écrites (celles des corrigés des fiches) ;
les suivantes attendent encore leur code (« raise NotImplementedError »).
Un état est un quadruplet (x, y, vx, vy).
"""
import heapq
import random
from collections import deque
from squelette import ACC, segment_libre, touche, dans, choisir, lire, cap_depart


# ---- TP 1 : les coups permis et le glouton ----
def ecart(a, lo, hi):
    """L'écart entre a et l'intervalle [lo, hi] (0 si a est dedans)."""
    if a < lo:
        return lo - a
    if a > hi:
        return a - hi
    return 0


def distance(p, arrivee):
    meilleure = -1
    for r in arrivee:
        dx = ecart(p[0], r[0], r[2])
        dy = ecart(p[1], r[1], r[3])
        d = (dx ** 2 + dy ** 2) ** 0.5
        if meilleure == -1 or d < meilleure:
            meilleure = d
    return meilleure


def coups_possibles(grille, cap, etat):
    x, y, vx, vy = etat
    res = []
    for ax, ay in ACC:
        nvx, nvy = vx + ax, vy + ay
        if (nvx, nvy) == (0, 0):
            permis = False                    # interdit de s'arrêter
        elif (vx, vy) == (0, 0):              # au départ : bon cap
            permis = cap is None or nvx * cap[0] + nvy * cap[1] > 0
        else:
            permis = nvx * vx + nvy * vy >= 0     # pas de demi-tour
        if permis and segment_libre(grille, (x, y), (x + nvx, y + nvy)):
            res.append((x + nvx, y + nvy, nvx, nvy))
    return res


def glouton(grille, depart, arrivee, cap):
    etat = (depart[0], depart[1], 0, 0)
    chemin = [etat]
    for i in range(100):
        suivants = coups_possibles(grille, cap, etat)
        if len(suivants) == 0:
            return "bloque", chemin
        etat = suivants[0]
        for e in suivants:        # < strict : à égalité, le premier de ACC
            if distance((e[0], e[1]), arrivee) < distance((etat[0], etat[1]), arrivee):
                etat = e
        chemin.append(etat)
        if dans(arrivee, (etat[0], etat[1])):
            return "arrive", chemin
    return "boucle", chemin


# ---- TP 2 : le graphe des états et le parcours en largeur ----
def construire(grille, depart, arrivee, cap):
    s0 = (depart[0], depart[1], 0, 0)
    adj = {s0: None}
    a_traiter = deque([s0])
    while len(a_traiter) > 0:
        s = a_traiter.popleft()
        if dans(arrivee, (s[0], s[1])):
            adj[s] = []                   # arrivée : la course est finie
        else:
            adj[s] = coups_possibles(grille, cap, s)
            for t in adj[s]:
                if t not in adj:
                    adj[t] = None
                    a_traiter.append(t)
    return adj


def remonter(pere, s):
    chemin = []
    while s is not None:
        chemin = [s] + chemin
        s = pere[s]
    return chemin


def largeur(adj, s0, arrivee):
    """Le Stratège : parcours en largeur du graphe adj depuis s0.
    Précondition : adj contient s0 et tous les états qu'on atteint depuis s0 ;
    arrivee est une liste de rectangles (x0, y0, x1, y1).
    Postcondition : renvoie (n, chemin, découverts) ; chemin va de s0 à un état
    d'arrivée en n coups, le plus petit nombre possible ; (None, [], découverts)
    si l'arrivée est inaccessible ; découverts compte les états vus."""
    pere = {s0: None}
    file = deque([s0])
    while len(file) > 0:
        s = file.popleft()
        for t in adj[s]:
            if t not in pere:
                pere[t] = s
                if dans(arrivee, (t[0], t[1])):
                    chemin = remonter(pere, t)
                    return len(chemin) - 1, chemin, len(pere)
                file.append(t)
    return None, [], len(pere)


def profondeur(adj, s0, arrivee):
    """Comme largeur, avec une pile."""
    pere = {s0: None}
    pile = [s0]
    while len(pile) > 0:
        s = pile.pop()
        for t in adj[s]:
            if t not in pere:
                pere[t] = s
                if dans(arrivee, (t[0], t[1])):
                    chemin = remonter(pere, t)
                    return len(chemin) - 1, chemin, len(pere)
                pile.append(t)
    return None, [], len(pere)


# ---- TP 3 : les coûts et Dijkstra ----
def cases_sable(grille):
    sable = []
    for y in range(len(grille)):
        for x in range(len(grille[y])):
            if grille[y][x] == "s":
                sable.append((x, y, x + 1, y + 1))
    return sable


def cout(sable, s, t, c):
    for r in sable:
        if touche((s[0], s[1]), (t[0], t[1]), r):
            return c
    return 1


def cout_chemin(sable, chemin, c):
    total = 0
    for i in range(len(chemin) - 1):
        total = total + cout(sable, chemin[i], chemin[i + 1], c)
    return total


def dijkstra(sable, adj, s0, arrivee, c):
    """Le Stratège pondéré : Dijkstra, avec un tas.
    Précondition : comme largeur ; sable est la liste des cases de sable ;
    c >= 1 est le coût d'un coup qui touche du sable.
    Postcondition : renvoie (coût, chemin, fixés, découverts) ; chemin va de s0
    à un état d'arrivée et son coût, le plus petit possible, vaut coût ;
    (None, [], fixés, découverts) si l'arrivée est inaccessible."""
    dist = {s0: 0}
    pere = {s0: None}
    tas = [(0, s0)]
    fixes = {}
    while len(tas) > 0:
        d, s = heapq.heappop(tas)
        if s not in fixes:
            fixes[s] = True
            if dans(arrivee, (s[0], s[1])):
                return d, remonter(pere, s), len(fixes), len(dist)
            for t in adj[s]:
                nd = d + cout(sable, s, t, c)
                if t not in dist or nd < dist[t]:
                    dist[t] = nd
                    pere[t] = s
                    heapq.heappush(tas, (nd, t))
    return None, [], len(fixes), len(dist)


# ---- TP 4 : l'heuristique cinématique et A* ----
def coups_min_1d(lo, hi, v):
    n = 0
    while not (n * v - n * (n + 1) // 2 <= hi
               and n * v + n * (n + 1) // 2 >= lo):
        n = n + 1
    return n


def h(etat, arrivee):
    x, y, vx, vy = etat
    meilleur = -1
    for r in arrivee:
        nx = coups_min_1d(r[0] - x, r[2] - x, vx)
        ny = coups_min_1d(r[1] - y, r[3] - y, vy)
        if nx > ny:
            n = nx
        else:
            n = ny
        if meilleur == -1 or n < meilleur:
            meilleur = n
    return meilleur


def vol(etat, arrivee):
    """La distance à vol d'oiseau (l'heuristique du Fonceur)."""
    return distance((etat[0], etat[1]), arrivee)


def astar(sable, adj, s0, arrivee, c, hf):
    """Renvoie (coût, chemin, états fixés, états découverts)."""
    g = {s0: 0}
    pere = {s0: None}
    tas = [(hf(s0, arrivee), 0, s0)]
    fixes = {}
    while len(tas) > 0:
        f, d, s = heapq.heappop(tas)
        if s not in fixes:
            fixes[s] = True
            if dans(arrivee, (s[0], s[1])):
                return d, remonter(pere, s), len(fixes), len(g)
            for t in adj[s]:
                nd = d + cout(sable, s, t, c)
                if t not in g or nd < g[t]:
                    g[t] = nd
                    pere[t] = s
                    heapq.heappush(tas, (nd + hf(t, arrivee), nd, t))
    return None, [], len(fixes), len(g)


# ---- TP 5 : spécifier, tester, comparer à un oracle ----
def mes_tests(dijkstra):
    """Mes tests de dijkstra (activité 2). Le labo appelle mes_tests avec la
    vraie dijkstra, puis avec six versions fausses : chaque version fausse doit
    faire échouer au moins un assert, la vraie aucun."""
    circuits = {}
    for nom in ["DA", "N", "S"]:
        grille, depart, arrivee = lire(open("circuit_" + nom + ".txt").read())
        adj = construire(grille, depart, arrivee, cap_depart(grille, depart, arrivee))
        circuits[nom] = (cases_sable(grille), adj, (depart[0], depart[1], 0, 0), arrivee)
    sable, adj, s0, arrivee = circuits["DA"]
    cout_da, chemin, fixes, vus = dijkstra(sable, adj, s0, arrivee, 3)
    assert cout_da == 1                          # le plus petit circuit : un coup
    assert chemin[0] == s0                       # le chemin part du départ
    assert dans(arrivee, chemin[-1][:2])         # et finit sur l'arrivée
    sable, adj, s0, arrivee = circuits["N"]
    assert dijkstra(sable, adj, s0, arrivee, 3)[0] is None   # aucune solution
    sable, adj, s0, arrivee = circuits["S"]
    cout_s, chemin, fixes, vus = dijkstra(sable, adj, s0, arrivee, 3)
    assert cout_s == 5                           # le sable compte (coût 3)
    assert cout_chemin(sable, chemin, 3) == cout_s     # le coût annoncé est celui du chemin
    attendus = [4, 5, 5, 5, 5, 5, 5]             # le jeu, sable 1 à 7 (TP 3)
    for c in range(1, 8):
        assert dijkstra(sable, adj, s0, arrivee, c)[0] == attendus[c - 1]


def alea(graine, L=12, H=7, p_mur=0.08, p_sable=0.15):
    """Un circuit aléatoire, en grille texte lisible par lire.
    Précondition : graine entier ; L >= 4 et H >= 1 ; p_mur et p_sable
    positives, de somme au plus 1.
    Postcondition : une chaîne de H lignes de L caractères, chacune terminée
    par "\\n" ; chaque case vaut "#", "s" ou ".", sauf D en (1, H // 2) et A en
    (L - 2, H // 2) ; deux appels avec la même graine renvoient le même circuit.
    Le circuit peut n'avoir aucune solution."""
    r = random.Random(graine)
    lignes = []
    for y in range(H):
        ligne = []
        for x in range(L):
            u = r.random()
            if u < p_mur:
                ligne.append("#")
            elif u < p_mur + p_sable:
                ligne.append("s")
            else:
                ligne.append(".")
        lignes.append(ligne)
    lignes[H // 2][1] = "D"
    lignes[H // 2][L - 2] = "A"
    texte = ""
    for ligne in lignes:
        for car in ligne:
            texte = texte + car
        texte = texte + "\n"
    return texte


def oracle(sable, adj, s0, arrivee, c):
    """Le programme de référence : le plus petit coût pour atteindre l'arrivée
    (None si elle est inaccessible), par une file et des distances corrigées
    tant qu'elles baissent. Écrit autrement que dijkstra, pour la contrôler."""
    dist = {s0: 0}
    file = deque([s0])
    while len(file) > 0:
        s = file.popleft()
        for t in adj[s]:
            nd = dist[s] + cout(sable, s, t, c)
            if t not in dist or nd < dist[t]:
                dist[t] = nd
                file.append(t)          # t devra propager sa nouvelle valeur
    meilleur = None
    for s, d in dist.items():
        if dans(arrivee, (s[0], s[1])) and (meilleur is None or d < meilleur):
            meilleur = d
    return meilleur


# ---- TP 6 : la programmation dynamique ----
INF = float("inf")


def reste_naif(sable, adj, s, k, arrivee, c, cpt):
    """R(s, k) : le plus petit coût pour finir depuis s en au plus k coups
    (INF si impossible), sans mémo. cpt[0] compte les appels (+1 en entrant)."""
    raise NotImplementedError("reste_naif")


def reste(sable, adj, s, k, arrivee, c, memo, cpt):
    """Comme reste_naif, avec le dictionnaire memo[(s, k)] : on y range
    chaque valeur calculée (pas les cas de base : arrivée, k = 0)."""
    raise NotImplementedError("reste")


def reconstruire(sable, adj, s, k, arrivee, c, memo):
    """Le trajet de coût R(s, k) : à chaque coup, le premier successeur t
    (ordre de adj[s]) tel que cout(s, t) + R(t, k - 1) = R(s, k)."""
    raise NotImplementedError("reconstruire")


# ---- TP 7 : les k plus proches voisins ----
def lire_exemples(texte, circuits=None):
    """Lit un jeu d'exemples exporté par le labo (fourni) : (Xa, Ya).
    circuits : les lettres des circuits à garder ("ABC"), tous si None."""
    Xa, Ya = [], []
    lignes = texte.split("\n")
    for ligne in lignes[1:]:                   # la ligne 0 est l'en-tête
        champs = ligne.split(";")
        garder = len(champs) >= 6
        if garder and circuits is not None and len(champs) > 6:
            garder = champs[6].split()[1] in circuits    # « Circuit A » -> A
        if garder:
            Xa.append((int(champs[0]), int(champs[1]), int(champs[2]), int(champs[3])))
            Ya.append((int(champs[4]), int(champs[5])))
    return Xa, Ya


def dist2(p, q):
    """Le carré de la distance euclidienne (fourni)."""
    total = 0
    for i in range(len(p)):
        total = total + (p[i] - q[i]) ** 2
    return total


def knn(Xa, Ya, x, k):
    """Le vote des k plus proches voisins de x.
    Égalité de distance : le plus petit indice d'abord.
    Égalité de votes : l'étiquette du voisin le plus proche."""
    raise NotImplementedError("knn")


def conduire(adj, s0, arrivee, Xa, Ya, k, n_max=40):
    """Voisins conduit depuis s0 : à chaque coup, l'accélération votée par
    knn sur le vecteur (dx, dy, vx, vy), où (dx, dy) va de la voiture au
    coin haut-gauche de la première case d'arrivée.
    Renvoie (arrivé ?, chemin) ; en cas d'échec, le chemin finit par le
    coup illégal."""
    raise NotImplementedError("conduire")


# ---- TP 8 : les k-moyennes ----
def d2(p, q):
    """Le carré de la distance euclidienne (comme dist2, fourni)."""
    total = 0
    for i in range(len(p)):
        total = total + (p[i] - q[i]) ** 2
    return total


def kmoyennes(X, k, graine=0, n_max=100):
    """Les k-moyennes : centres de départ r.sample(range(len(X)), k) avec
    r = random.Random(graine) ; affecter (égalité : le plus petit c),
    recentrer, jusqu'à des affectations inchangées.
    Renvoie (centres, affectations, inertie, nombre de tours)."""
    raise NotImplementedError("kmoyennes")


# ---- TP 11 : les jeux à deux joueurs ----
def attracteur(adj, arrivee):
    """Un coup sur deux : les positions (s, j) gagnantes pour J1, où j (1 ou 2)
    est le joueur qui doit jouer. Renvoie un dictionnaire {(s, j): True}."""
    raise NotImplementedError("attracteur")


def gagnants(adj, arrivee):
    """Je propose, tu choisis : le rang de chaque état gagnant pour J1
    (0 à l'arrivée). Renvoie un dictionnaire {état: rang}."""
    raise NotImplementedError("gagnants")


def proposer(adj, s, rang):
    """La stratégie de J1 : les deux successeurs gagnants de plus petit rang
    (égalité : le plus petit état). Renvoie la liste des états proposés."""
    raise NotImplementedError("proposer")


def valeur(adj, s, k, arrivee, cpt):
    """La valeur minmax de s quand J1 doit proposer et regarde k coups devant :
    100 à l'arrivée, -100 bloqué, -h(s, arrivee) si k vaut 0.
    cpt[0] augmente de 1 à chaque appel."""
    raise NotImplementedError("valeur")


def proposer_minmax(adj, s, k, arrivee, cpt):
    """Les deux successeurs de plus grande valeur (k - 1 coups devant)."""
    raise NotImplementedError("proposer_minmax")


def partie(adj, s0, arrivee, rang, k):
    """Une partie contre l'adversaire parfait choisir : J1 joue proposer si
    k vaut 0, proposer_minmax sinon. Renvoie (issue, coups, appels), issue
    valant "J1 gagne", "J2 gagne" ou "nul" (40 coups)."""
    raise NotImplementedError("partie")
